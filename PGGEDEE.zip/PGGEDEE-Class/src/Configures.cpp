#include "Configures.h"

Configures* conf;


Configures::Configures() {
}
