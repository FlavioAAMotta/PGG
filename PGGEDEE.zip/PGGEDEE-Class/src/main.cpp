#include <iostream>
#include "Database.h"
#include "Grammar.h"
#include "No.h"
#include "Configures.h"
#include "Search.h"
#include "Configures.h"
#include "SimpleParser.h"
#include "../include/ClassificationParser.h"
#include "ParserDerivadas.h"
#include "LeastSquareParser.h"
#include "LSDerivadasParser.h"
#include "IndividuoBuilder.h"
#include "LeastSquareIndividuoBuilder.h"
#include "RK4LSDerivadasParser.h"
#include "RK4LSIndividuoBuilder.h"
#include "Subject.h"
#include "RK4sParser.h"
#include "RK4AGParser.h"
#include "RK4LSDParser.h"
#include <sstream>

#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
//#include <boost/algorithm/string.hpp>
//#include "DifferencialEvolution.h"

using namespace std;

#define simpleParser
//#define RK4Parser
int main(int argc, char** argv){

    cout << "Hello GP-ufjf!" << endl;
    conf = new Configures();

    conf->approach = atoi(argv[5]);
	srand(atoi(argv[1]));

    //set parametros
    conf->MAXDEEP = 8;

    conf->generations = 10;
    conf->popSize = 500;
    conf->elitism = 0.1;
    conf->crossoverRate = 0.9;
    conf->mutationRate = 0.9;

    conf->NUM_THREADS = 1;

    /// Loading database and grammar
	data = new Database(argv[3]);
	data->loadGroup(argv[4]); // 1000.grp pra 1000, pgDE pra 50
//	grammar = new Grammar("input/grammar/itaDE.dat"); // itaDE.dat para DE, ita.dat para apenas PG
	grammar = new Grammar(argv[2]); // itaDE.dat para DE, ita.dat para apenas PG
#define normal

#ifdef normal

    conf->numTree = data->prediction; // seta o numero de variaveis a serem preditas. dependente do problema a ser tratado
    cout << "NumTree: " << conf->numTree << endl;
//    grammar->print();
//    cin.get();
    //data->print();
    double** dados_treino = data->values;
    //cout << "total training " << data->totalTraining << " total test " << data->totalTest << " total validation "<< data->totalValidation << endl;

     IndividuoBuilder * individuoBuilder = NULL;

    /// Setting parser

    #ifdef simpleParser
        ClassificationParser * parser = new ClassificationParser();
        ClassificationParser * parserTest = new ClassificationParser();
        ClassificationParser * parserValidation = new ClassificationParser();
        individuoBuilder = new SimpleIndividuoBuilder();
    #endif

//    cout << "Seed : " << seed << endl;
    cout << "TotalTrain : " << data->totalTraining << endl;
    cout << "TotalTest : " << data->totalTest << endl;
    cout << "TotalValidation : " << data->totalValidation << endl;
    parser->setDataSet(data->training,data->totalTraining);
    parserTest->setDataSet(data->test,data->totalTest);
    parserValidation->setDataSet(data->validation,data->totalValidation);

    grammar->addConstant(-9);
    grammar->addConstant(-8);
    grammar->addConstant(-7);
    grammar->addConstant(-6);
    grammar->addConstant(-5);
    grammar->addConstant(-4);
    grammar->addConstant(-3);
    grammar->addConstant(-2);
    grammar->addConstant(-1);
    grammar->addConstant(0);
    grammar->addConstant(1);
    grammar->addConstant(2);
    grammar->addConstant(3);
    grammar->addConstant(4);
    grammar->addConstant(5);
    grammar->addConstant(6);
    grammar->addConstant(7);
    grammar->addConstant(8);
    grammar->addConstant(9);

    grammar->addConstant(-100);
    grammar->addConstant(-10);
    grammar->addConstant(10);
    grammar->addConstant(100);

    Search* s = new Search(parser, NULL, individuoBuilder);
    s->setParserTest(parserTest);
    s->setParserValidation(parserValidation);
    s->stepByStep = false;
    //conf->wall_timer = omp_get_wtime();
    s->evolve(); // Execucao para o DE
//    s->evolvePG();
//
//    cout <<  "\n TotalLS : " << conf->totalLS << "\nDeu ruim LS : "<< conf->deuRuimOLS <<endl;
//    cout << "% que deu Ruim : "<< (100.0/((double)conf->totalLS+conf->deuRuimOLS))*conf->deuRuimOLS << "%" << endl;
#endif/*
    int conta3 = 0;
    int conta2 = 0;
    int cont1 = 0;
    int cont2 = 0;
    int cont3 = 0;
    for(int i = 0; i < 210; i+=1){
        if(conta3 < 3){
            cout << i << " ";
            conta3++;
            cont1++;
            if(conta3==3){
                conta2 = 0;
            }
        }else if(conta2 < 2){
            conta2++;
            if(conta2 == 2){
                conta3 = 0;
            }
        }
    }
    cout << endl;
    for(int i = 3; i < 210; i+=5){
        cout << i << " ";
        cont2++;
    }
    cout << endl;
    for(int i = 4; i < 210; i+=5){
        cout << i << " ";
        cont3++;
    }
    cout << endl;

    cout << cont1 << " ";
    cout << cont2 << " ";
    cout << cont3 << " ";

    return 0;*/
}
