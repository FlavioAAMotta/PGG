#include "SimpleIndividuoBuilder.h"

SimpleIndividuoBuilder::SimpleIndividuoBuilder() {
    //ctor
}

SimpleIndividuoBuilder::~SimpleIndividuoBuilder() {
    //dtor
}
