#include "TournamentSelection.h"

TournamentSelection::TournamentSelection() {
    this->tam_selection = 2;
}

TournamentSelection::~TournamentSelection() {
    //dtor
}
