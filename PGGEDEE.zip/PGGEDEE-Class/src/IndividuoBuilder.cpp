#include "IndividuoBuilder.h"

IndividuoBuilder::IndividuoBuilder() {
    //ctor
}

IndividuoBuilder::~IndividuoBuilder() {
    //dtor
}
