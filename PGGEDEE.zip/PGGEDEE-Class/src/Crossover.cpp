#include "Crossover.h"

Crossover::Crossover() {
    //ctor
}

Crossover::~Crossover() {
    //dtor
}
