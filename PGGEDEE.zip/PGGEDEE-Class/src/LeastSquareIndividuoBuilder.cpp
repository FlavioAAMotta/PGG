#include "LeastSquareIndividuoBuilder.h"

LeastSquareIndividuoBuilder::LeastSquareIndividuoBuilder() {
    //ctor
}

LeastSquareIndividuoBuilder::~LeastSquareIndividuoBuilder() {
    //dtor
}
