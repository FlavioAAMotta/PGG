#include "RK4LSIndividuoBuilder.h"

RK4LSIndividuoBuilder::RK4LSIndividuoBuilder() {
    //ctor
}

RK4LSIndividuoBuilder::~RK4LSIndividuoBuilder() {
    //dtor
}
