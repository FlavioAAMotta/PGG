#include "Mutation.h"

Mutation::~Mutation() {
    //dtor
}
