#include "Selection.h"

Selection::Selection() {
    //ctor
}

Selection::~Selection() {
    //dtor
}
