#!/bin/bash
start=${2}
end=${3}
grammar='wdbc.dat'
grammarDE='wdbc.dat'
for problem in 'wdbc'
do
	id=${1}
	#Todos os casos sao apenas no melhor individuo
	mkdir output/all/$problem
	mkdir output/all/$problem/0 #GGP normal
	mkdir output/all/$problem/1 #GGPEE 1,2 durante	
	mkdir output/all/$problem/2 #GGPDE durante 
	mkdir output/all/$problem/3 #GGPEE 1,1 durante 
	mkdir output/all/$problem/4 #GGPEE 1,4 durante
	
	for i in `seq $start $end`;
	do
		echo 'Resolvendo ' $problem ' seed: ' $i 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wdbc.grp'
		for j in `seq 0 4`;
		do
			echo '--- '$j
			./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wdbc.grp' $j  > output/all/$problem/$j/$((id + i)).txt
		done
	done
done
