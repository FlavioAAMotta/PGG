#ifndef CLASSIFICATIONPARSER_H
#define CLASSIFICATIONPARSER_H

#include "../src/Configures.h"
#include "../src/Parser.h"
#include "../src/SimpleIndividuo.h"
#include "../src/DifferencialEvolution.h"
#include "../src/EvolutionStrategie.h"
#include <vector>
#include <stack>
#include <tuple>
#include <cmath>


class ClassificationParser : public Parser{
    public:
        ClassificationParser();
        virtual string nameParser();
        virtual double Evaluate(Subject* s);
        virtual void Optimize(Subject* s);
        virtual double Operate(int opType, int opValue, double a, double b = NULL, double c = NULL);

        double** dataset;
        DifferencialEvolution* diffEvo;
        EvolutionStrategie* evoStrat;

        virtual void setDataSet(double ** x,int tam) {
            tamDataset = tam;
            dataset = x;
        }

        virtual void printResult(Subject * s) {}
        ~ClassificationParser();

    protected:
        int tamDataset;

    private:
    double AuxEvaluate(Subject* s, int model, double* dat);
};

#endif // CLASSIFICATIONPARSER_H
