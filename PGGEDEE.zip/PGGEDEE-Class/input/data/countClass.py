import os
import sys
from numpy import *
file = sys.argv[1]
tmp = ""
classes = ""

with open(file) as f:
	for cnt, line in enumerate(f):
	       classes += line.strip()[-1:]
	       #tmp += (line.strip()[-1])
print classes
print ("0: ", classes.count('0'))
print ("1: ", classes.count('1'))
print ("2: ", classes.count('2'))
print ("3: ", classes.count('3'))
print ("4: ", classes.count('4'))
print ("5: ", classes.count('5'))
print ("6: ", classes.count('6'))
print ("7: ", classes.count('7'))
