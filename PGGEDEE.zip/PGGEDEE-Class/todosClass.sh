#!/bin/bash
start=${2}
end=${3}
for problem in 'seed' 'ionosphere' 'steel-plates' 'vertebral' 'wdbc' 'wine' 'iris' 
do
	id=${1}
	#comentarios errados para os approaches
	#Todos os casos sao apenas no melhor individuo
	mkdir output/all/$problem
	mkdir output/all/$problem/0 #GGP normal
	mkdir output/all/$problem/1 #GGPDE 1,2 durante	
	mkdir output/all/$problem/2 #GGPDE durante 
	mkdir output/all/$problem/3 #GGPEE 1,1 durante 
	mkdir output/all/$problem/4 #GGPEE 1,4 durante
	#mkdir output/all/$problem/5 #GGPDE no final 10%
#	mkdir output/all/$problem/6 #GGPEE 1,1 final 10%
#	mkdir output/all/$problem/7 #GGPEE 1,2 final 10%
#	mkdir output/all/$problem/8 #GGPEE 1,4 final 10%
#	mkdir output/all/$problem/9 #GGPDE final 5%
#	mkdir output/all/$problem/10 #GGPEE 1,1 final 5%
#	mkdir output/all/$problem/11 #GGPEE 1,2 final 5%
#	mkdir output/all/$problem/12 #GGPEE 1,4 final 5%
#	mkdir output/all/$problem/13 #GGPEE 1,2 durante	
#	mkdir output/all/$problem/14 #GGPDE durante 
#	mkdir output/all/$problem/15 #GGPEE 1,1 durante 
#	mkdir output/all/$problem/16 #GGPEE 1,4 durante
#	mkdir output/all/$problem/17 #GGPDE no final 10%
#	mkdir output/all/$problem/18 #GGPEE 1,1 final 10%
#	mkdir output/all/$problem/19 #GGPEE 1,2 final 10%
#	mkdir output/all/$problem/20 #GGPEE 1,4 final 10%
#	mkdir output/all/$problem/21 #GGPDE final 5%
#	mkdir output/all/$problem/22 #GGPEE 1,1 final 5%
#	mkdir output/all/$problem/23 #GGPEE 1,2 final 5%
#	mkdir output/all/$problem/24 #GGPEE 1,4 final 5%
	
	if [ "$problem" == "iris" ]; then
		grammarDE='iris.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/iris.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/iris.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi
	if [ "$problem" == "seed" ]; then
		grammarDE='seed.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/seed.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/seed.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "glass" ]; then
		grammarDE='glass.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/glass.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/glass.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "ionosphere" ]; then
		grammarDE='ionosphere.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/ionosphere.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/ionosphere.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "steel-plates" ]; then
		grammarDE='steel-plates.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/steel-plates.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/steel-plates.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "vertebral" ]; then
		grammarDE='vertebral.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/vertebral.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/vertebral.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "wdbc" ]; then
		grammarDE='wdbc.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wdbc.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wdbc.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi

	if [ "$problem" == "wine" ]; then
		grammarDE='wine.dat'
		for i in `seq $start $end`;
		do
			echo 'Resolvendo ' $problem ' seed: ' $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wine.grp'
			for j in `seq 0 4`;
			do
				echo '--- '$j
				./bin/Release/PGGClass $((id + i)) 'input/grammar/'$grammarDE 'input/data/'$problem'.dat' 'input/data/wine.grp' $j  > output/all/$problem/$j/$((id + i)).txt
			done
		done
	fi
done
